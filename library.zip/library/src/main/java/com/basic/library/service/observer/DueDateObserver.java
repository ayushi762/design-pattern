package com.basic.library.service.observer;

public class DueDateObserver implements Observer {
    private String memberName;

    public DueDateObserver(String memberName) {
        this.memberName = memberName;
    }

    @Override
    public void update(String message) {
        System.out.println("Reminder for " + memberName + ": " + message);
    }
}
