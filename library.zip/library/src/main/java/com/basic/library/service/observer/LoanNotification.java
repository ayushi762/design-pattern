package com.basic.library.service.observer;

public class LoanNotification extends Observable {
    public void sendDueDateNotification() {
        notifyObservers("Book due date is approaching soon.");
    }

    public void sendOverdueNotification() {
        notifyObservers("Book is overdue! Please return it.");
    }
}
