package com.basic.library.model;

public class Member extends User {
    public Member(String name) {
        super(null, name);
    }

    @Override
    public String getRole() { return "Member"; }
}