package com.basic.library;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
//public class LibraryApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(LibraryApplication.class, args);
//	}
//
//}


import com.basic.library.model.Book;
import com.basic.library.model.User;
import com.basic.library.service.LibraryFacade;
import com.basic.library.service.UserFactory;
import com.basic.library.service.UserRegistry;
import com.basic.library.controller.*;
import java.util.Scanner;

public class LibraryApplication {

 public static void main(String[] args) {
     LibraryFacade libraryFacade = new LibraryFacade();
     LibraryController controller = new LibraryController(libraryFacade);

     // Register users
     User member = UserFactory.createUser("Member", "Alice");
     User librarian = UserFactory.createUser("Librarian", "Bob");
     UserRegistry.getInstance().registerUser(member);
     UserRegistry.getInstance().registerUser(librarian);

     Scanner scanner = new Scanner(System.in);
     boolean running = true;

     while (running) {
         System.out.println("\n--- E-Library System ---");
         System.out.println("1. Add Book");
         System.out.println("2. Update Book");
         System.out.println("3. Delete Book");
         System.out.println("4. Borrow Book");
         System.out.println("5. Return Book");
         System.out.println("6. View Users");
         System.out.println("7. Register User");
         System.out.println("8. Update User");
         System.out.println("9. Delete User");
         System.out.println("10. View Books");
         System.out.println("11. View Active Loans");
         System.out.println("12. View Overdue Loans");
         System.out.println("13. Send notifications");
         System.out.println("0. Exit");
         System.out.print("Enter choice: ");

         int choice = scanner.nextInt();
         scanner.nextLine(); 

         switch (choice) {
             case 1 -> addBook(controller, scanner);
             case 2 -> updateBook(controller, scanner);
             case 3 -> deleteBook(controller, scanner);
             case 4 -> borrowBook(controller, scanner);
             case 5 -> returnBook(controller, scanner);
             case 6 -> controller.viewUsers();
             case 7 -> registerUser(controller, scanner);
             case 8 -> updateUser(controller, scanner);
             case 9 -> deleteUser(controller, scanner);
             case 10 -> controller.viewBooks();
             case 11 -> controller.viewActiveLoans();
             case 12 -> controller.viewOverdueLoans();
             case 13 -> controller.sendNotification();
             case 0 -> running = false;
             default -> System.out.println("Invalid choice. Try again.");
         }
     }
     scanner.close();
 }

 // Helper methods to interact with controller

 private static void addBook(LibraryController controller, Scanner scanner) {
     System.out.print("Enter title: ");
     String title = scanner.nextLine();
     System.out.print("Enter author: ");
     String author = scanner.nextLine();
     System.out.print("Enter ISBN: ");
     String isbn = scanner.nextLine();
     System.out.print("Enter category: ");
     String category = scanner.nextLine();

     controller.addBook(title, author, isbn, category);
 }

 private static void updateBook(LibraryController controller, Scanner scanner) {
     System.out.print("Enter ISBN of the book to update: ");
     String isbn = scanner.nextLine();
     System.out.print("Enter new title: ");
     String title = scanner.nextLine();
     System.out.print("Enter new author: ");
     String author = scanner.nextLine();
     System.out.print("Enter new category: ");
     String category = scanner.nextLine();

     controller.updateBook(isbn, title, author, category);
 }

 private static void deleteBook(LibraryController controller, Scanner scanner) {
     System.out.print("Enter ISBN of the book to delete: ");
     String isbn = scanner.nextLine();
     controller.deleteBook(isbn);
 }

 private static void borrowBook(LibraryController controller, Scanner scanner) {
	 System.out.print("Enter User ID: ");
	    String userId = scanner.nextLine();
	    User user = UserRegistry.getInstance().findUserById(userId);
	    
	    if (user != null) {
           System.out.print("Enter ISBN of the book to borrow: ");
           String isbn = scanner.nextLine();
           controller.borrowBook(user, isbn);
	    } else {
	        System.out.println("User not found with ID: " + userId);
	    }
 }

 private static void returnBook(LibraryController controller, Scanner scanner) {
	 System.out.print("Enter User ID: ");
	    String userId = scanner.nextLine();
	    User user = UserRegistry.getInstance().findUserById(userId);

	    if (user != null) {
	        System.out.print("Enter ISBN of the book to return: ");
	        String isbn = scanner.nextLine();
	        controller.returnBook(user, isbn);
	    } else {
	        System.out.println("User not found with ID: " + userId);
	    }
 }
 
 private static void registerUser(LibraryController controller, Scanner scanner) {
     System.out.print("Enter user role (e.g., Member, Librarian): ");
     String role = scanner.nextLine();
//     System.out.print("Enter user ID: ");
//     String id = scanner.nextLine();
     System.out.print("Enter user name: ");
     String name = scanner.nextLine();
     controller.registerUser(role, name);
 }

 private static void updateUser(LibraryController controller, Scanner scanner) {
     System.out.print("Enter user ID to update: ");
     String id = scanner.nextLine();
     System.out.print("Enter new name: ");
     String newName = scanner.nextLine();
     controller.updateUser(id, newName);
 }

 private static void deleteUser(LibraryController controller, Scanner scanner) {
     System.out.print("Enter user ID to delete: ");
     String id = scanner.nextLine();
     controller.deleteUser(id);
 }
}


