package com.basic.library.service.commands;

import com.basic.library.model.Book;
import com.basic.library.service.LibraryCatalog;

public class UpdateBookCommand implements Command {
    private Book oldBook;
    private Book updatedBook;

    public UpdateBookCommand(Book oldBook, Book updatedBook) {
        this.oldBook = oldBook;
        this.updatedBook = updatedBook;
    }

    @Override
    public void execute() {
        LibraryCatalog catalog = LibraryCatalog.getInstance();
        catalog.removeBook(oldBook);
        catalog.addBook(updatedBook);
        System.out.println("Updated book: " + updatedBook.getTitle());
    }
}
