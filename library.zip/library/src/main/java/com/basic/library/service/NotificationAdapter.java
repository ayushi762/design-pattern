package com.basic.library.service;

//Adapter pattern
public class NotificationAdapter {
    private NotificationService notificationService;

    public NotificationAdapter(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    public void sendNotification(String message) {
        notificationService.notify(message);
    }
}
