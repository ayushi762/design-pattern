package com.basic.library.service;

public class NotificationService {
    public void notify(String message) {
        System.out.println("Notification: " + message);
    }
}
