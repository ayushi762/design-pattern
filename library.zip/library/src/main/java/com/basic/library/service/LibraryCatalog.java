package com.basic.library.service;

import com.basic.library.iterator.BookIterator;
//Singleton Pattern
import com.basic.library.model.Book;
import java.util.ArrayList;
import java.util.List;

public class LibraryCatalog {
    private static LibraryCatalog instance;
    private List<Book> books = new ArrayList<>();

    private LibraryCatalog() {}

    public static LibraryCatalog getInstance() {
        if (instance == null) {
            instance = new LibraryCatalog();
        }
        return instance;
    }

    public void addBook(Book book) {
    	if (findBookByISBN(book.getISBN()) != null) {
            throw new IllegalArgumentException("A book with ISBN " + book.getISBN() + " already exists.");
        }
        books.add(book);
    }

    public void removeBook(Book book) {
        books.remove(book);
    }
    
    public Book findBookByISBN(String isbn) {
    	BookIterator iterator = new BookIterator(books);
        while (iterator.hasNext()) {
            Book book = iterator.next();
            if (book.getISBN().equals(isbn)) {
                return book;
            }
        }
        return null;
//        for (Book book : books) {
//            if (book.getISBN().equals(isbn)) {
//                return book;
//            }
//        }
//        return null;  // Returns null if book is not found
    }

    public List<Book> getAllBooks() {
        return books;
    }
}
