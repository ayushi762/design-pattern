package com.basic.library.service.commands;

public interface Command {
    void execute();
}
