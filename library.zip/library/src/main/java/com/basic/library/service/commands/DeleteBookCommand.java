package com.basic.library.service.commands;

import com.basic.library.model.Book;
import com.basic.library.service.LibraryCatalog;

public class DeleteBookCommand implements Command {
    private Book book;

    public DeleteBookCommand(Book book) {
        this.book = book;
    }

    @Override
    public void execute() {
        LibraryCatalog.getInstance().removeBook(book);
        System.out.println("Deleted book: " + book.getTitle());
    }
}
