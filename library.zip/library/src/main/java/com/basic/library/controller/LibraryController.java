package com.basic.library.controller;

import com.basic.library.model.Book;
import com.basic.library.model.Loan;
import com.basic.library.model.User;
import com.basic.library.service.LibraryFacade;
import com.basic.library.service.UserFactory;
import com.basic.library.service.UserRegistry;

import java.util.List;

public class LibraryController {

    private final LibraryFacade libraryFacade;
    private UserRegistry userRegistry;

    public LibraryController(LibraryFacade libraryFacade) {
    	if (libraryFacade == null) {
            throw new IllegalArgumentException("LibraryFacade must not be null.");
        }
        this.libraryFacade = libraryFacade;
        this.userRegistry = UserRegistry.getInstance();
    }

    // Method to add a book
    public void addBook(String title, String author, String isbn, String category) {
    	try {
            if (title == null || author == null || isbn == null || category == null) {
                throw new IllegalArgumentException("Book details must not be null.");
            }
            Book book = new Book(title, author, isbn, category);
            libraryFacade.addBook(book);
        } catch (Exception e) {
            System.err.println("Failed to add book: " + e.getMessage());
        }
    }

    // Method to update an existing book by ISBN
    public void updateBook(String isbn, String newTitle, String newAuthor, String newCategory) {
        try {
        	Book oldBook = libraryFacade.getBookByISBN(isbn);
        
        if (oldBook != null) {
            Book updatedBook = new Book(newTitle, newAuthor, isbn, newCategory);
            libraryFacade.updateBook(oldBook, updatedBook);
        } else {
            System.out.println("Book with ISBN " + isbn + " not found.");
        }
        } catch (Exception e) {
            System.err.println("Failed to update book: " + e.getMessage());
        }
    }

    // Method to delete a book by ISBN
    public void deleteBook(String isbn) {
    	try {
        Book book = libraryFacade.getBookByISBN(isbn);
        if (book != null) {
            libraryFacade.deleteBook(book);
            System.out.println("Book deleted: " + book);
        } else {
            System.out.println("Book with ISBN " + isbn + " not found.");
        }
    	} catch (Exception e) {
            System.err.println("Failed to delete book: " + e.getMessage());
        }
    }

    // Method to borrow a book by a user
    public void borrowBook(User user, String isbn) {
    	try {
            if (user == null || isbn == null) {
                throw new IllegalArgumentException("User and ISBN must not be null.");
            }
        Book book = libraryFacade.getBookByISBN(isbn);
        if (book != null) {
            libraryFacade.borrowBook(user, book);
        } else {
            System.out.println("Book with ISBN " + isbn + " not found.");
        }
    	} catch (Exception e) {
            System.err.println("Failed to borrow book: " + e.getMessage());
        }
    }

    // Method to return a book by a user
    public void returnBook(User user, String isbn) {
    	try {
            if (user == null || isbn == null) {
                throw new IllegalArgumentException("User and ISBN must not be null.");
            }
        Book book = libraryFacade.getBookByISBN(isbn);
        if (book != null) {
            libraryFacade.returnBook(user, book);
        } else {
            System.out.println("Book with ISBN " + isbn + " not found.");
        }
    	} catch (Exception e) {
            System.err.println("Failed to return book: " + e.getMessage());
        }
    }
    
    public void registerUser(String role, String name) {
    	 try {
             if (role == null || name == null) {
                 throw new IllegalArgumentException("Role and name must not be null.");
             }
        User user = UserFactory.createUser(role, name);
        userRegistry.registerUser(user);
    	 } catch (Exception e) {
             System.err.println("Failed to register user: " + e.getMessage());
         }
    }

    public void updateUser(String id, String newName) {
    	try {
        userRegistry.updateUser(id, newName);
    	} catch (Exception e) {
            System.err.println("Failed to update user: " + e.getMessage());
        }
    }

    public void deleteUser(String id) {
      try {
        userRegistry.deleteUser(id);
      } catch (Exception e) {
            System.err.println("Failed to delete user: " + e.getMessage());
       }
    }

    // Method to view all registered users
    public void viewUsers() {
      try {
        List<User> users = UserRegistry.getInstance().getUsers();
        if (users.isEmpty()) {
            System.out.println("No registered users.");
        } else {
            users.forEach(user -> {
                System.out.println("User ID: " + user.getId() + ", Name: " + user.getName() + ", Role: " + user.getRole());
            });
        }
      } catch (Exception e) {
            System.err.println("Failed to retrieve users: " + e.getMessage());
      }
    }

    // Method to view all books in the library
    public void viewBooks() {
      try {
        List<Book> books = libraryFacade.getAllBooks();
        if (books.isEmpty()) {
            System.out.println("No books available in the library.");
        } else {
            books.forEach(book -> {
                System.out.println("Book Title: " + book.getTitle() + ", Author: " + book.getAuthor() +
                        ", ISBN: " + book.getISBN() + ", Category: " + book.getCategory());
            });
        }
      } catch (Exception e) {
          System.err.println("Failed to retrieve books: " + e.getMessage());
      }
    }
    
    //Method to view active loans
    public void viewActiveLoans() {
    	try {
    	 List<Loan> activeLoans = libraryFacade.getActiveLoans();
    	 if (activeLoans.isEmpty()) {
             System.out.println("No active loans.");
         } else {
             System.out.println("Active Loans:");
             for (Loan loan : activeLoans) {
                System.out.println("User: " + loan.getUser().getName() + ", Book: " + loan.getBook().getTitle() + ", Due Date: " + loan.getDueDate());
             }
         }
    	} catch (Exception e) {
            System.err.println("Failed to retrieve active loans: " + e.getMessage());
        }
    }
    
    //Method to view due loans
    public void viewOverdueLoans() {
      try {
    	List<Loan> overdueLoans = libraryFacade.getOverdueLoans();
    	if (overdueLoans.isEmpty()) {
            System.out.println("No overdue loans.");
        } else {
        System.out.println("Overdue Loans:");
        for (Loan loan : overdueLoans) {
            System.out.println("User: " + loan.getUser().getName() + ", Book: " + loan.getBook().getTitle() + ", Due Date: " + loan.getDueDate());
        }
        }
      } catch (Exception e) {
          System.err.println("Failed to retrieve overdue loans: " + e.getMessage());
      }
    }
    
    public void sendNotification() {
      try {
        libraryFacade.notifyAllDueDates();
        System.out.println("Notifications sent successfully.");
      } catch (Exception e) {
        System.err.println("Failed to send notifications: " + e.getMessage());
    }
    }
}
