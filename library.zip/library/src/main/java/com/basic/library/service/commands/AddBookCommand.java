package com.basic.library.service.commands;

import com.basic.library.model.Book;
import com.basic.library.service.LibraryCatalog;

public class AddBookCommand implements Command {
    private Book book;

    public AddBookCommand(Book book) {
        this.book = book;
    }

    @Override
    public void execute() {
      try {
        LibraryCatalog.getInstance().addBook(book);
        System.out.println("Added book: " + book.getTitle());
      }  catch (IllegalArgumentException e) {
          System.err.println(e.getMessage());
      }
    }
}
