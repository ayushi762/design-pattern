package com.basic.library.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.Date;
import java.time.ZoneId;

public class Loan {
    private Book book;
    private User user;
    private Date loanDate;
    private Date dueDate;
    private boolean returned;

    public Loan(Book book, User user) {
    	if (book == null || user == null) {
            throw new IllegalArgumentException("Book and User must not be null.");
        }
        this.book = book;
        this.user = user;
        this.loanDate = new Date();
        this.dueDate = calculateDueDate();
//        this.dueDate = dueDate;
        this.returned = false;
    }
    private Date calculateDueDate() {
        // Assuming the due date is set to 1 day from the loan date
    	try
    	{
        long dueMillis = loanDate.getTime() + (1 * 24 * 60 * 60 * 1000); // 1 days in milliseconds
        return new Date(dueMillis);
    	} catch (Exception e) {
            throw new RuntimeException("Error calculating due date.", e);
        }
    }

    public Book getBook() { 
    	if (book == null) {
          throw new IllegalStateException("Book information is not available.");
        }
    	return book; 
    }
    public User getUser() { return user; }
    public Date getDueDate() { return dueDate; }
    public boolean isReturned() { return returned; }

    public void markAsReturned() {
        this.returned = true;
    }
    
    public boolean isDueSoon() {
        LocalDate today = LocalDate.now();
        LocalDate dueDateLocal = convertToLocalDate(dueDate);
        long daysUntilDue = java.time.temporal.ChronoUnit.DAYS.between(today, dueDateLocal);
        return daysUntilDue <= 2 && daysUntilDue >= 0 && !isOverdue(); // due soon and not overdue
    }

    // Method to check if the due date has passed
    public boolean isOverdue() {
        LocalDate today = LocalDate.now();
        LocalDate dueDateLocal = convertToLocalDate(dueDate);
        return today.isAfter(dueDateLocal) && !returned;
    }

    // Helper method to convert Date to LocalDate
    private LocalDate convertToLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
