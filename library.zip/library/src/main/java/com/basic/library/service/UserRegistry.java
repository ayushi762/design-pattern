package com.basic.library.service;

import com.basic.library.iterator.UserIterator;
import com.basic.library.model.User;

import java.util.ArrayList;
import java.util.List;

//Singleton
public class UserRegistry {
    private static UserRegistry instance;
    private List<User> users = new ArrayList<>();
    private static int idCounter = 1;

    private UserRegistry() {}

    public static UserRegistry getInstance() {
        if (instance == null) {
            instance = new UserRegistry();
        }
        return instance;
    }

    public void registerUser(User user) {
    	user.setId(String.valueOf(idCounter++));
        users.add(user);
        System.out.println("User registered successfully in Registry: " + user.getName());
    }
 
    public void updateUser(String id, String newName) {
//        for (User user : users) {
//            if (user.getId().equals(id)) {
//                user.setName(newName);
//                System.out.println("User updated successfully: " + user.getName());
//                return;
//            }
//        }
    	UserIterator iterator = new UserIterator(users);
        while (iterator.hasNext()) {
            User user = iterator.next();
            if (user.getId().equals(id)) {
                user.setName(newName);
                System.out.println("User updated successfully: " + user.getName());
                return;
            }
        }
        System.out.println("User not found with ID: " + id);
    }

    public void deleteUser(String id) {
    	UserIterator iterator = new UserIterator(users);
        boolean found = false;
        while (iterator.hasNext()) {
            User user = iterator.next();
            if (user.getId().equals(id)) {
                users.remove(user);
                System.out.println("User deleted successfully: " + user.getName());
                found = true;
                break;
            }
        }
        
//        boolean found = false;
//        for (User user : users) {
//            if (user.getId().equals(id)) {
//                users.remove(user);
//                System.out.println("User deleted successfully: " + user.getName());
//                found = true;
//                break;
//            }
//        }
        if (!found) {
            System.out.println("User not found with ID: " + id);
        }
    }
    

    public List<User> getUsers() {
        return users;
    }

	public User findUserById(String userId) {
		UserIterator iterator = new UserIterator(users);
	    while (iterator.hasNext()) {
	        User user = iterator.next();
	        if (user.getId().equals(userId)) {
	            return user;
	        }
	    }
	    return null;
//		for (User user : users) {
//            if (user.getId().equals(userId)) {
//            	return user;
//            }
//	  }
//		return null;
	}
}
