package com.basic.library.service;

import com.basic.library.model.Book;
import com.basic.library.model.Loan;
import com.basic.library.model.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LoanService {
    private static LoanService instance;
    private List<Loan> loans = new ArrayList<>();

    private LoanService() {}

    public static LoanService getInstance() {
        if (instance == null) {
            instance = new LoanService();
        }
        return instance;
    }

    public void createLoan(User user, Book book) {
        Loan loan = new Loan(book, user); 
        loans.add(loan);
    }

    public void returnLoan(User user, Book book) {
        for (Loan loan : loans) {
            if (loan.getUser().equals(user) && loan.getBook().equals(book) && !loan.isReturned()) {
                loan.markAsReturned();
                System.out.println("Book returned: " + book.getTitle());
                break;
            }
        }
    }
    
    public List<Loan> getActiveLoans() {
        List<Loan> activeLoans = new ArrayList<>();
        for (Loan loan : loans) {
            if (!loan.isReturned()) {
                activeLoans.add(loan);
            }
        }
        return activeLoans;
    }
    
    public List<Loan> getOverdueLoans() {
        List<Loan> overdueLoans = new ArrayList<>();
        for (Loan loan : loans) {
            if (!loan.isReturned() && loan.getDueDate().before(new Date())) {
                overdueLoans.add(loan);
            }
        }
        return overdueLoans;
    }

    public List<Loan> getLoans() {
        return loans;
    }
}
