package com.basic.library.model;

public class Librarian extends User {
    public Librarian(String name) {
        super(null, name);
    }

    @Override
    public String getRole() { return "Librarian"; }
}