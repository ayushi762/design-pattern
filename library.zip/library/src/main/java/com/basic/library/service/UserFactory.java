package com.basic.library.service;

//Factory Method Pattern
import com.basic.library.model.User;
import com.basic.library.model.Member;
import com.basic.library.model.Librarian;

public class UserFactory {
    public static User createUser(String type, String name) {
        switch (type) {
            case "Member":
                return new Member(name);
            case "Librarian":
                return new Librarian(name);
            default:
                throw new IllegalArgumentException("Unknown user type");
        }
    }
}
