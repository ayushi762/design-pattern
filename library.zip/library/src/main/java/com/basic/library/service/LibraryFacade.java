package com.basic.library.service;

import com.basic.library.model.Book;
import com.basic.library.model.Loan;
import com.basic.library.model.User;
import com.basic.library.service.commands.AddBookCommand;
import com.basic.library.service.commands.DeleteBookCommand;
import com.basic.library.service.commands.UpdateBookCommand;
import com.basic.library.service.observer.LoanNotification;
import com.basic.library.service.observer.DueDateObserver;

import java.util.Date;
import java.util.List;

public class LibraryFacade {
    private LibraryCatalog catalog;
    private LoanService loanService;
    private NotificationAdapter notificationAdapter;

    public LibraryFacade() {
        this.catalog = LibraryCatalog.getInstance();
        this.loanService = LoanService.getInstance();
        this.notificationAdapter = new NotificationAdapter(new NotificationService());
    }

    public void addBook(Book book) {
    	if (catalog.findBookByISBN(book.getISBN()) != null) {
            System.out.println("A book with ISBN " + book.getISBN() + " already exists. Cannot add duplicate.");
            return;
        }
        new AddBookCommand(book).execute();
    }

    public void deleteBook(Book book) {
        new DeleteBookCommand(book).execute();
    }

    public void updateBook(Book oldBook, Book updatedBook) {
        new UpdateBookCommand(oldBook, updatedBook).execute();
    }
    
    public List<Book> getAllBooks() {
        return catalog.getAllBooks(); 
    }
    
    public Book getBookByISBN(String isbn) {
        return catalog.findBookByISBN(isbn);  
    }

    public void borrowBook(User user, Book book) {
    	 if ("Librarian".equalsIgnoreCase(user.getRole())) {
    	        System.out.println("Librarians are not allowed to borrow books.");
    	        return;
    	    }
        loanService.createLoan(user, book);
        System.out.println(user.getName() + " borrowed the book: " + book.getTitle());
    }

    public void returnBook(User user, Book book) {
    	if ("Librarian".equalsIgnoreCase(user.getRole())) {
            System.out.println("Librarians are not allowed to return books.");
            return;
        }
        loanService.returnLoan(user, book);
    }

    public List<Loan> getActiveLoans() {
        return loanService.getActiveLoans();
    }

    public List<Loan> getOverdueLoans() {
        return loanService.getOverdueLoans();
    }

    public void notifyDueDate(User user) {
        LoanNotification loanNotification = new LoanNotification();
        loanNotification.addObserver(new DueDateObserver(user.getName()));
        loanNotification.sendDueDateNotification();
    }
    
    public void notifyAllDueDates() {
        LoanNotification loanNotification = new LoanNotification();
        List<Loan> loans = loanService.getActiveLoans();
        for (Loan loan : loans) {
            if (loan.isDueSoon()) {  // Assuming Loan has isDueSoon() method
                User user = loan.getUser();
                DueDateObserver observer = new DueDateObserver(user.getName());
                loanNotification.addObserver(observer);
                loanNotification.sendDueDateNotification();
                loanNotification.removeObserver(observer); // Cleanup observer after notification
            } else if (loan.isOverdue()) {  // Assuming Loan has isOverdue() method
                User user = loan.getUser();
                DueDateObserver observer = new DueDateObserver(user.getName());
                loanNotification.addObserver(observer);
                loanNotification.sendOverdueNotification();
                loanNotification.removeObserver(observer); // Cleanup observer after notification
            }
        }
    }
}