package com.smarthome.automation.utils;

import com.smarthome.automation.services.RequestContext;

import java.util.ArrayList;
import java.util.List;

public class InterceptorChain {
    private final List<Interceptor> interceptors = new ArrayList<>();

    public void addInterceptor(Interceptor interceptor) {
        interceptors.add(interceptor);
    }

    public void executeInterceptors(RequestContext context) {
        for (Interceptor interceptor : interceptors) {
            interceptor.intercept(context);
        }
    }
}
