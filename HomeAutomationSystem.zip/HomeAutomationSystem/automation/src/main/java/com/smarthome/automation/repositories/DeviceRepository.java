package com.smarthome.automation.repositories;

import com.smarthome.automation.models.Device;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DeviceRepository {
    private final List<Device> devices = new ArrayList<>();
    private int currentId = 1;

    public void addDevice(Device device) {
        device.setId(currentId++);
        devices.add(device);
    }
    
    public Optional<Device> findByName(String name) {
        return devices.stream()
                      .filter(device -> device.getName().equalsIgnoreCase(name))
                      .findFirst();
    }

    public boolean updateDevice(int id, Device updatedDevice) {
        for (int i = 0; i < devices.size(); i++) {
            if (devices.get(i).getId() == id) {
                updatedDevice.setId(id);
                devices.set(i, updatedDevice);
                return true;
            }
        }
        return false;
    }
    
    public boolean updateDeviceStatus(int id, boolean status) {
        Optional<Device> existingDevice = devices.stream().filter(device -> device.getId() == id).findFirst();
        if (existingDevice.isPresent()) {
            existingDevice.get().setStatus(status);
            return true;
        }
        return false;
    }


    public boolean deleteDevice(int id) {
        return devices.removeIf(device -> device.getId() == id);
    }

    public List<Device> getDevices() {
        return new ArrayList<>(devices);
    }
}
