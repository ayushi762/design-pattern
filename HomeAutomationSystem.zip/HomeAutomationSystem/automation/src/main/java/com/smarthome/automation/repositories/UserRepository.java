package com.smarthome.automation.repositories;

import com.smarthome.automation.models.User;

import java.util.ArrayList;
import java.util.List;

public class UserRepository {
    private final List<User> users = new ArrayList<>();
    private int currentId = 1;

    public void addUser(User user) {
        user.setId(currentId++);
        users.add(user);
    }

    public boolean updateUser(int id, User updatedUser) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                updatedUser.setId(id);
                users.set(i, updatedUser);
                return true;
            }
        }
        return false;
    }

    public boolean deleteUser(int id) {
        return users.removeIf(user -> user.getId() == id);
    }

    public List<User> getUsers() {
        return new ArrayList<>(users);
    }
}
