package com.smarthome.automation.services;

public class NotificationObserver implements Observer {
	private final String observerName;

    public NotificationObserver(String observerName) {
        this.observerName = observerName;
    }

    @Override
    public void update(String message) {
        System.out.println("[" + observerName + "] Notification: " + message);

//        System.out.println("Received notification: " + message);
    }
}
