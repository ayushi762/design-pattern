package com.smarthome.automation.services;

import com.smarthome.automation.models.AutomationRule;
import com.smarthome.automation.repositories.AutomationRulesRepository;
import com.smarthome.automation.repositories.DeviceRepository;
import com.smarthome.automation.utils.ConditionEvaluator;
import com.smarthome.automation.utils.Logger;

import java.time.LocalTime;
import java.util.List;

public class AutomationRulesService {
	private static final String TAG = "RuleExecution";
    private final AutomationRulesRepository rulesRepository;
    private final DeviceManagementService deviceService;
    private final NotificationService notificationService;

    public AutomationRulesService(DeviceManagementService deviceService,NotificationService notificationService) {
        this.rulesRepository = new AutomationRulesRepository();
        this.deviceService = deviceService;
        this.notificationService = notificationService;
    }

	public void addRule(AutomationRule rule) {
        try {
            rulesRepository.addRule(rule);
            Logger.info(TAG, "Automation rule added: " + rule);
            notificationService.notifyObservers("New automation rule added: " + rule.getName());
        } catch (Exception e) {
            Logger.error(TAG, "Failed to add automation rule: " + e.getMessage());
        }
    }

    public void updateRule(int id, AutomationRule updatedRule) {
        try {
            if (rulesRepository.updateRule(id, updatedRule)) {
                Logger.info(TAG, "Automation rule updated: " + updatedRule);
                notificationService.notifyObservers("Automation rule updated: " + updatedRule.getName());
            } else {
                Logger.warn(TAG, "Automation rule not found with ID: " + id);
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to update automation rule: " + e.getMessage());
        }
    }

    public void deleteRule(int id) {
        try {
            if (rulesRepository.deleteRule(id)) {
                Logger.info(TAG, "Automation rule deleted: ID " + id);
                notificationService.notifyObservers("Automation rule deleted: " + id);
            } else {
                Logger.warn(TAG, "Automation rule not found with ID: " + id);
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to delete automation rule: " + e.getMessage());
        }
    }

    public void viewRules() {
        try {
            List<AutomationRule> rules = rulesRepository.getRules();
            if (rules.isEmpty()) {
                Logger.info(TAG, "No automation rules registered.");
            } else {
            rules.forEach(rule -> Logger.info(TAG, rule.toString()));
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to fetch automation rules: " + e.getMessage());
        }
    }
    
    public AutomationRule getRuleById(int id) {
        List<AutomationRule> rules = rulesRepository.getRules();
        for (AutomationRule rule : rules) {
            if (rule.getId() == id) {
                return rule;
            }
        }
        return null; 
    }
    
    public List<AutomationRule> getRules() {
        try {
            return rulesRepository.getRules();
        } catch (Exception e) {
            Logger.error(TAG, "Failed to fetch rules: " + e.getMessage());
            return List.of();
        }
    }

    
//    private void executeAction(String action) {
//        // Parse and execute the action, e.g., "setDeviceStatus(LivingRoomLight, true)"
//        if (action.startsWith("setDeviceStatus")) {
//            String[] parts = action.substring(action.indexOf('(') + 1, action.indexOf(')')).split(",");
//            String deviceName = parts[0].trim(); 
//            boolean status = Boolean.parseBoolean(parts[1].trim()); 
//
//            deviceService.updateDeviceStatus(deviceName, status);
//        }
//    }
   
    public void executeRules() {
        List<AutomationRule> rules = rulesRepository.getRules();
        for (AutomationRule rule : rules) {
        	System.out.println("Local time now" + LocalTime.now());
            if (rule.getScheduleTime() != null && rule.getScheduleTime().equals(LocalTime.now())) {
                executeAction(rule.getAction());
                notificationService.notifyObservers("Scheduled rule executed: " + rule.getName());
            } else if (ConditionEvaluator.evaluate(rule.getCondition())) {
                executeAction(rule.getAction());
                notificationService.notifyObservers("Condition met for rule: " + rule.getName());
            }
        }
    }
    public void executeAction(String action) {
        try {
            if (action.startsWith("setDeviceStatus")) {
                String[] parts = action.substring(action.indexOf('(') + 1, action.indexOf(')')).split(",");
                String deviceName = parts[0].trim();
                boolean status = Boolean.parseBoolean(parts[1].trim());
                deviceService.updateDeviceStatus(deviceName, status);
                notificationService.notifyObservers("Action executed: " + action);
                Logger.info(TAG, "Action executed: " + action);
            } else {
                Logger.warn(TAG, "Unsupported action: " + action);
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to execute action: " + e.getMessage());
        }
    }
}
