package com.smarthome.automation.utils;

import java.util.ArrayList;
import java.util.List;

public class Logger {
    private static final List<LogEntry> logEntries = new ArrayList<>();

    public static void info(String tag, String message) {
        log("[INFO]", tag, message);
    }

    public static void warn(String tag, String message) {
        log("[WARN]", tag, message);
    }

    public static void error(String tag, String message) {
        log("[ERROR]", tag, message);
    }

    private static void log(String level, String tag, String message) {
        String logMessage = level + " [" + tag + "] " + message;
        System.out.println(logMessage);
        logEntries.add(new LogEntry(level, tag, message));
    }
    
    public static List<String> getLogsByTag(String tag) {
        List<String> filteredLogs = new ArrayList<>();
        for (LogEntry entry : logEntries) {
            if (entry.getTag().equals(tag)) {
                filteredLogs.add(entry.toString());
            }
        }
        return filteredLogs;
    }


//    public static List<LogEntry> getLogsByTag(String tag) {
//        List<LogEntry> filteredLogs = new ArrayList<>();
//        for (LogEntry entry : logEntries) {
//            if (entry.getTag().equals(tag)) {
//                filteredLogs.add(entry);
//            }
//        }
//        return filteredLogs;
//    }

    public static void clearLogs() {
        logEntries.clear();
    }

    private static class LogEntry {
        private final String level;
        private final String tag;
        private final String message;

        public LogEntry(String level, String tag, String message) {
            this.level = level;
            this.tag = tag;
            this.message = message;
        }

        public String getTag() {
            return tag;
        }

        @Override
        public String toString() {
            return level + " [" + tag + "] " + message;
        }
    }
}


//public class Logger {
//    private static final List<String> logMessages = new ArrayList<>();
//
//    public static void info(String message) {
//    	String log = "[INFO] " + message;
//        System.out.println(log);
//        logMessages.add(log);
//    }
//
//    public static void warn(String message) {
//        String log = "[WARN] " + message;
//        System.out.println(log);
//        logMessages.add(log);
//    }
//
//    public static void error(String message) {
//        String log = "[ERROR] " + message;
//        System.out.println(log);
//        logMessages.add(log);
//    }
//
//    public static List<String> getLogs() {
//        return new ArrayList<>(logMessages); 
//    }
//
//    public static void clearLogs() {
//        logMessages.clear();
//    }
//
//}
