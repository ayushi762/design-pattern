package com.smarthome.automation.utils;

import com.smarthome.automation.services.RequestContext;

public class LoggingInterceptor implements Interceptor {
    @Override
    public void intercept(RequestContext context) {
        System.out.println("[INFO] " + context.getMessage());
    }
}
