package com.smarthome.automation.utils;

import com.smarthome.automation.models.Device;

public class LazyDeviceProxy extends Device {
    private boolean isDetailsLoaded = false;
	private Device actualDevice;

    public LazyDeviceProxy(int id, String name, String type, boolean status) {
        super(id, name, type, status); 
    }

    public LazyDeviceProxy(Device actualDevice) {
        super(actualDevice.getId(), actualDevice.getName(), actualDevice.getType(), actualDevice.isStatus());
        this.actualDevice = actualDevice;
    }

	// Simulates loading device details lazily
    private void loadDetails() {
        if (!isDetailsLoaded) {
            System.out.println("Loading device details for " + getName() + "...");
            isDetailsLoaded = true;
        }
    }
    
    @Override
    public String getDetails() {
        loadDetails();
        return actualDevice.getDetails();
    }

    @Override
    public String toString() {
        loadDetails();
        return super.toString();
    }
}
