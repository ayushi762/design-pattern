package com.smarthome.automation;

import com.smarthome.automation.models.AutomationRule;
import com.smarthome.automation.models.Device;
import com.smarthome.automation.services.*;
import com.smarthome.automation.utils.ConditionEvaluator;
import com.smarthome.automation.utils.ServiceLocator;

import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Initialize the service locator
		DeviceManagementService deviceService = ServiceLocator.getDeviceService();
		UserManagementService userService = ServiceLocator.getUserService();
		AutomationRulesService rulesService = ServiceLocator.getAutomationRulesService();
		NotificationService notificationService = ServiceLocator.getNotificationService();
		ReportService reportingService = ServiceLocator.getReportingService();

		SchedulerService schedulerService = new SchedulerService(rulesService);

		// Start the scheduler
		schedulerService.startScheduler();

		// Create and register observers
		NotificationObserver adminObserver = new NotificationObserver("Admin1");

		notificationService.subscribe(adminObserver);

		// Add devices
		Device light = new Device(1, "SmartLight", "Light", false);
		Device thermostat = new Device(2, "SmartThermostat", "Thermostat", false);

		deviceService.addDevice(light);
		deviceService.addDevice(thermostat);
		
		AutomationRule rule1 = new AutomationRule(1, "Turn on smart light when motion detected", "motiondetected==true", "setDeviceStatus(SmartLight,true)", null);
		rulesService.addRule(rule1);
		
//		AutomationRule rule2 = new AutomationRule(2, "Turn off smart light at 13:20", null, "setDeviceStatus(SmartLight,false)", 14:12:41.410701700);
//		rulesService.addRule(rule2);
		
		System.out.println("Welcome to Smart Home Automation System!");
		boolean running = true;

		while (running) {
			try {
				System.out.println("\nPlease choose an option:");
				System.out.println("1. Manage Devices");
				System.out.println("2. Manage Users");
				System.out.println("3. Manage Automation Rules");
//            System.out.println("4. View Notifications");
				System.out.println("4. Generate Reports");
				System.out.println("5. Exit");

				int choice = scanner.nextInt();
				scanner.nextLine(); 

				switch (choice) {
				case 1:
					manageDevices(scanner, deviceService);
					break;
				case 2:
					manageUsers(scanner, userService);
					break;
				case 3:
					manageAutomationRules(scanner, rulesService);
					break;
//				case 4:
////                	notificationService.subscribe()
//					break;
				case 4:
					manageReports(scanner, reportingService);
//                    reportingService.generateReport("device_usage");
//                    reportingService.generateReport("UserManagement");
					break;
				case 5:
					running = false;
					System.out.println("Exiting the system. Goodbye!");
					break;
				default:
					System.out.println("Invalid choice. Please try again.");
				}
			} catch (RuntimeException e) {
				System.out.println("Error: " + e.getMessage());
			} catch (Exception e) {
				System.out.println("An unexpected error occurred: " + e.getMessage());
			}
		}
		Runtime.getRuntime().addShutdownHook(new Thread(schedulerService::stopScheduler));
		scanner.close();
	}

	private static void manageReports(Scanner scanner, ReportService reportingService) {
		System.out.println("\nReports Management:");
		System.out.println("1. Device Usage");
		System.out.println("2. User Activity");
		System.out.println("3. Automation Rule Execution");
		System.out.print("Choose an option: ");

		int choice = scanner.nextInt();
		scanner.nextLine();
		String report = "";

		switch (choice) {
		case 1:
			report = reportingService.generateReport("DeviceManagement");
			break;
		case 2:
			report = reportingService.generateReport("UserManagement");
			break;
		case 3:
			report = reportingService.generateReport("RuleExecution");
			break;
		default:
			System.out.println("Invalid choice.");
			return;
		}	
		System.out.println("\n" + report);
	}

	private static void manageDevices(Scanner scanner, DeviceManagementService deviceService) {
		System.out.println("\nDevice Management:");
		System.out.println("1. Add Device");
		System.out.println("2. Update Device");
		System.out.println("3. Delete Device");
		System.out.println("4. View Devices");
		System.out.print("Choose an option: ");

		int choice = scanner.nextInt();
		scanner.nextLine();

		switch (choice) {
		case 1:
			System.out.print("Enter Device Name: ");
			String name = scanner.nextLine();
			System.out.print("Enter Device Type (e.g., Light, Thermostat, Camera): ");
			String type = scanner.nextLine();
			Device newDevice = new Device(0, name, type, false); // false for inactive
			deviceService.addDevice(newDevice);
//                deviceService.addDevice(name, type);
			break;
		case 2:
//                System.out.print("Enter Device ID to Update: ");
//                int deviceId = scanner.nextInt();
			System.out.print("Enter Device Name: ");
			String newName = scanner.nextLine();
			System.out.print("Enter New Device Status:(true/false) ");
			boolean newStatus = scanner.nextBoolean();
			deviceService.updateDeviceStatus(newName, newStatus);
			break;
		case 3:
			System.out.print("Enter Device ID to Delete: ");
			int deleteId = scanner.nextInt();
			deviceService.deleteDevice(deleteId);
			break;
		case 4:
			deviceService.viewDevices();
			break;
		default:
			System.out.println("Invalid choice.");
			return;
		}
	}

	private static void manageUsers(Scanner scanner, UserManagementService userService) {
		System.out.println("\nUser Management:");
		System.out.println("1. Register User");
		System.out.println("2. Update User");
		System.out.println("3. Delete User");
		System.out.println("4. View Users");
		System.out.print("Choose an option: ");

		int choice = scanner.nextInt();
		scanner.nextLine();

		switch (choice) {
		case 1:
			System.out.print("Enter User Name: ");
			String name = scanner.nextLine();
			System.out.print("Enter Role (Homeowner/Admin): ");
			String role = scanner.nextLine();
			userService.addUser(name, role);
			break;
		case 2:
			System.out.print("Enter User ID to Update: ");
			int userId = scanner.nextInt();
			scanner.nextLine();
			System.out.print("Enter New User Name: ");
			String newName = scanner.nextLine();
			System.out.print("Enter New Role (Homeowner/Admin): ");
			String newRole = scanner.nextLine();
			userService.updateUser(userId, newName, newRole);
//                userService.updateUser(userId, newName);
			break;
		case 3:
			System.out.print("Enter User ID to Delete: ");
			int deleteId = scanner.nextInt();
			userService.deleteUser(deleteId);
			break;
		case 4:
			userService.viewUsers();
			break;
		default:
			System.out.println("Invalid choice.");
			return;
		}
	}

	private static void manageAutomationRules(Scanner scanner, AutomationRulesService rulesService) {
		System.out.println("\nAutomation Rules Management:");
		System.out.println("1. Create Rule");
		System.out.println("2. Update Rule");
		System.out.println("3. Delete Rule");
		System.out.println("4. View Rules");
		System.out.println("5. Execute Rules manually");
		System.out.print("Choose an option: ");

		int choice = scanner.nextInt();
		scanner.nextLine();

		switch (choice) {
		case 1:
			System.out.print("Enter Rule Name: ");
			String name = scanner.nextLine();
			System.out.print("Enter Trigger Condition (e.g., motionDetected == true): ");
			String condition = scanner.nextLine();
			System.out.print("Enter Action (e.g., setDeviceStatus(device_name,true)): ");
			String action = scanner.nextLine();
			System.out.print("Enter Schedule Time (HH:mm or leave blank for condition-based): ");
			String scheduleInput = scanner.nextLine();

			LocalTime scheduleTime = null;
			if (!scheduleInput.isBlank()) {
				try {
					scheduleTime = LocalTime.parse(scheduleInput);
				} catch (Exception e) {
					System.out.println("Invalid time format. Use HH:mm.");
					return;
				}
			}

			AutomationRule newRule = new AutomationRule(0, name, condition, action, scheduleTime);
			rulesService.addRule(newRule);
//                rulesService.addRule(0, name, condition, action, scheduleTime);
			break;

		case 2:
			System.out.print("Enter Rule ID to Update: ");
			int ruleIdToUpdate = scanner.nextInt();
			scanner.nextLine();
			System.out.print("Enter New Rule Name: ");
			String newName = scanner.nextLine();
			System.out.print("Enter New Condition: ");
			String newCondition = scanner.nextLine();
			System.out.print("Enter New Action: ");
			String newAction = scanner.nextLine();
			System.out.print("Enter New Schedule Time (HH:mm or leave blank for condition-based): ");
			String newScheduleInput = scanner.nextLine();

			LocalTime newScheduleTime = null;
			if (!newScheduleInput.isBlank()) {
				try {
					newScheduleTime = LocalTime.parse(newScheduleInput);
				} catch (Exception e) {
					System.out.println("Invalid time format. Use HH:mm.");
					return;
				}
			}
			AutomationRule updatedRule = new AutomationRule(0, newName, newCondition, newAction, newScheduleTime);
			rulesService.updateRule(ruleIdToUpdate, updatedRule);
			break;

		case 3:
			System.out.print("Enter Rule ID to Delete: ");
			int ruleIdToDelete = scanner.nextInt();
			rulesService.deleteRule(ruleIdToDelete);
			break;

		case 4:
			rulesService.viewRules();
			break;

		case 5:
			System.out.println("Choose execution method:");
			System.out.println("1. Execute a saved rule by ID");
			System.out.println("2. Input custom condition and action");
			int execChoice = scanner.nextInt();
			scanner.nextLine();

			if (execChoice == 1) {
				System.out.print("Enter Rule ID to execute: ");
				int ruleId = scanner.nextInt();
				scanner.nextLine();
				AutomationRule ruleToExecute = rulesService.getRuleById(ruleId); 
				if (ruleToExecute != null && ConditionEvaluator.evaluate(ruleToExecute.getCondition())) {
					rulesService.executeAction(ruleToExecute.getAction());
//					System.out.println("Rule executed successfully.");
				} else {
					System.out.println("Condition not met or rule not found.");
				}
			} else if (execChoice == 2) {
				System.out.print("Enter Condition: ");
				String customCondition = scanner.nextLine();
				 boolean anyConditionMatched = false;

			        List<AutomationRule> rules = rulesService.getRules();
			        for (AutomationRule rule : rules) {
			            if (rule.getCondition().equalsIgnoreCase(customCondition)) { 
			                if (ConditionEvaluator.evaluate(rule.getCondition())) {
			                    rulesService.executeAction(rule.getAction());
			                    System.out.println("Action executed for matching rule: " + rule.getName());
			                    anyConditionMatched = true;
			                }
			            }
			        }

			        if (!anyConditionMatched) {
			            System.out.println("No matching condition found or condition not met.");
			        }
			    }
			break;

		default:
			System.out.println("Invalid choice.");
			return;
		}
	} 
}
