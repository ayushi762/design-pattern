package com.smarthome.automation.utils;

import java.util.Optional;

import com.smarthome.automation.models.Device;
import com.smarthome.automation.repositories.DeviceRepository;

public class ConditionEvaluator {
//	private static DeviceRepository deviceRepository;
//	
//	 public ConditionEvaluator(DeviceRepository deviceRepository) {
//	        ConditionEvaluator.deviceRepository = deviceRepository;
//	    }
    public static boolean evaluate(String condition) {
        if (condition == null) return false;
        String normalizedCondition = condition.trim().toLowerCase();

        if ("motiondetected==true".equals(normalizedCondition) || "iscold==true".equals(normalizedCondition)) {
            return true;
        }
        return false;
    }

//    String[] parts = condition.split("==");
//    if (parts.length == 2) {
//        String variable = parts[0].trim();
//        String value = parts[1].trim();
//
//        if (variable.equals("motionDetected")) {
//            return Boolean.parseBoolean(value);
//        }
//    }
//    public static boolean evaluate(String condition) {
//        String[] parts = condition.split("==");
//        String deviceName = parts[0].trim();
//        System.out.println("Device name" + deviceName);
//        boolean expectedStatus = Boolean.parseBoolean(parts[1].trim());
//
//		Optional<Device> deviceOptional = deviceRepository.findByName(deviceName);
//
//        if (deviceOptional.isPresent()) {
//            return deviceOptional.get().isStatus() == expectedStatus;
//        } else {
//            throw new RuntimeException("Device with name " + deviceName + " not found.");
//        }
//    }

}
