package com.smarthome.automation.services;

import com.smarthome.automation.models.Device;
import com.smarthome.automation.repositories.DeviceRepository;
import com.smarthome.automation.utils.DevicePoolManager;
import com.smarthome.automation.utils.InterceptorChain;
import com.smarthome.automation.utils.Logger;
import com.smarthome.automation.utils.LoggingInterceptor;

import java.util.List;
import java.util.Optional;

// Repository Design Pattern for managing in-memory data.
public class DeviceManagementService {
	private final DeviceRepository deviceRepository;
	private final DevicePoolManager devicePoolManager;
	private final NotificationService notificationService;
	private final InterceptorChain interceptorChain;
	private static final String TAG = "DeviceManagement";

	public DeviceManagementService(NotificationService notificationService) {
		this.deviceRepository = new DeviceRepository();
		this.devicePoolManager = new DevicePoolManager(6); // assuming poolsize 6
		this.notificationService = notificationService;
		this.interceptorChain = new InterceptorChain();
		interceptorChain.addInterceptor(new LoggingInterceptor());

//        notificationService.subscribe(new NotificationObserver());
	}

	public void addDevice(Device device) {
		Device pooledDevice = null;
		try {
			if (deviceRepository.findByName(device.getName()).isPresent()) {
				throw new RuntimeException("Device name must be unique.");
			}
			pooledDevice = devicePoolManager.acquireDevice();

			pooledDevice.setName(device.getName());

			pooledDevice.setType(device.getType());

			pooledDevice.setStatus(device.isStatus());
			deviceRepository.addDevice(device);
			RequestContext context = new RequestContext("Device added successfully: " + device);
            interceptorChain.executeInterceptors(context);
			Logger.info(TAG, "Device added successfully: " + device);
			notificationService.notifyObservers("Device added: " + device.getName());
		} catch (Exception e) {
			 RequestContext context = new RequestContext("Failed to add device: " + e.getMessage());
	            interceptorChain.executeInterceptors(context);
			Logger.error(TAG, "Failed to add device: " + e.getMessage());
		} finally {
			if (pooledDevice != null) {
				devicePoolManager.releaseDevice(pooledDevice);
			}
		}
	}

//    public void updateDevice(int id, Device updatedDevice) {
//        try {
//            if (deviceRepository.updateDevice(id, updatedDevice)) {
//                Logger.info("Device updated successfully: " + updatedDevice);
//            } else {
//                Logger.warn("Device not found with ID: " + id);
//            }
//        } catch (Exception e) {
//            Logger.error("Failed to update device: " + e.getMessage());
//        }
//    }

	public void updateDeviceStatus(String name, boolean status) {
		Device pooledDevice = null;
		try {
			Optional<Device> deviceOptional = deviceRepository.findByName(name);

			if (deviceOptional.isPresent()) {
				pooledDevice = devicePoolManager.acquireDevice();
				pooledDevice = deviceOptional.get();
				pooledDevice.setStatus(status);
//            Device device = deviceOptional.get();
//            device.setStatus(status);
              Logger.info(TAG, "Device status updated: " + name + " -> " + (status ? "Active" : "Inactive"));
				notificationService
						.notifyObservers("Device status updated: " + name + " -> " + (status ? "Active" : "Inactive"));
			} else {
				throw new RuntimeException("Device with name " + name + " not found.");
			}
		} catch (Exception e) {
			Logger.error(TAG, "Failed to update device status: " + e.getMessage());
		} finally {
			if (pooledDevice != null) {
				devicePoolManager.releaseDevice(pooledDevice);
			}
		}
	}

//    public void updateDeviceStatus(int id, boolean status) {
//        try {
//            if (deviceRepository.updateDeviceStatus(id, status)) {
//                Logger.info("Device status updated successfully: ID " + id + ", Status: " + (status ? "active" : "inactive"));
//            } else {
//                Logger.warn("Device not found with ID: " + id);
//            }
//        } catch (Exception e) {
//            Logger.error("Failed to update device status: " + e.getMessage());
//        }
//    }

	// Release device back to the pool
	public void releaseDevice(Device device) {

		devicePoolManager.releaseDevice(device);
	}

	public void deleteDevice(int id) {
		try {
			if (deviceRepository.deleteDevice(id)) {
				Logger.info(TAG, "Device deleted successfully: ID " + id);
				notificationService.notifyObservers("Device deleted: ID " + id);
			} else {
				Logger.warn(TAG, "Device not found with ID: " + id);
			}
		} catch (Exception e) {
			Logger.error(TAG, "Failed to delete device: " + e.getMessage());
		}
	}

	public void viewDevices() {
		try {
			List<Device> devices = deviceRepository.getDevices();
			if (devices.isEmpty()) {
				Logger.info(TAG, "No devices registered.");
				RequestContext context = new RequestContext("No devices registered.");
                interceptorChain.executeInterceptors(context);
			} else {
				devices.forEach(device -> {
				Logger.info(TAG, device.toString());
				RequestContext context = new RequestContext(device.toString());
                interceptorChain.executeInterceptors(context);
         
				});
			}
		} catch (Exception e) {
			RequestContext context = new RequestContext("Failed to fetch devices: " + e.getMessage());
            interceptorChain.executeInterceptors(context);
			Logger.error(TAG, "Failed to fetch devices: " + e.getMessage());
		}
	}
}
