package com.smarthome.automation.services;

import com.smarthome.automation.models.AutomationRule;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SchedulerService {
    private final AutomationRulesService rulesService;
    private final ScheduledExecutorService scheduler;

    public SchedulerService(AutomationRulesService rulesService) {
        this.rulesService = rulesService;
        this.scheduler = Executors.newScheduledThreadPool(1);
    }

    public void startScheduler() {
        scheduler.scheduleAtFixedRate(this::executeScheduledRules, 0, 1, TimeUnit.MINUTES);
    }

    private void executeScheduledRules() {
        List<AutomationRule> rules = rulesService.getRules();
//        LocalTime currentTime = LocalTime.now();
        LocalTime currentTime = LocalTime.now().truncatedTo(ChronoUnit.MINUTES);
        for (AutomationRule rule : rules) {
            if (rule.getScheduleTime() != null && rule.getScheduleTime().equals(currentTime)) {
                rulesService.executeAction(rule.getAction());
            } 
//            else if (ConditionEvaluator.evaluate(rule.getCondition())) {
//                rulesService.executeAction(rule.getAction());
//            }
        }
    }

    public void stopScheduler() {
        scheduler.shutdown();
    }
}


//public class SchedulerService {
//    private final AutomationRulesService ruleService;
//
//    public SchedulerService(AutomationRulesService ruleService) {
//        this.ruleService = ruleService;
//    }
//
//    public void startScheduler() {
//        Timer timer = new Timer(true);
//        timer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                ruleService.executeRules();
//            }
//        }, 0, 1000); 
//    }
//}
