package com.smarthome.automation.models;

public class Admin extends User {
    public Admin(String name) {
        super(name, "Admin");
    }
}
