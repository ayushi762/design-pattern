package com.smarthome.automation.utils;

import com.smarthome.automation.models.Device;

import java.util.LinkedList;
import java.util.Queue;

// Resource Pool for managing reusable Device objects
public class DevicePoolManager {
    private final Queue<Device> availableDevices = new LinkedList<>();
    private final int maxPoolSize;

    public DevicePoolManager(int maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
    }

 // Acquire a device from the pool
    public synchronized Device acquireDevice() {
        if (availableDevices.isEmpty()) {
            System.out.println("No available devices in the pool. Creating a new one.");
            return new LazyDeviceProxy(new Device(0, "Default Device", "Unknown", false)); 
        }
        System.out.println("Device acquired from the pool.");
        Device device = availableDevices.poll();
        return new LazyDeviceProxy(device);
    }


    // Release a device back to the pool
    public synchronized void releaseDevice(Device device) {
        if (availableDevices.size() < maxPoolSize) {
            availableDevices.offer(device);
            System.out.println("Device released back to the pool.");
        } else {
            System.out.println("Pool is full. Discarding device.");
        }
    }

    // Check the pool size
    public int getPoolSize() {
        return availableDevices.size();
    }
}
