package com.smarthome.automation.factories;

import com.smarthome.automation.models.Admin;
import com.smarthome.automation.models.HomeOwner;
import com.smarthome.automation.models.User;

public class UserFactory {
    public static User createUser(String name, String role) {
        switch (role.toLowerCase()) {
            case "homeowner":
                return new HomeOwner(name);
            case "admin":
                return new Admin(name);
            default:
                throw new IllegalArgumentException("Invalid role: " + role);
        }
    }
}
