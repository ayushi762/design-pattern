package com.smarthome.automation.models;

public class HomeOwner extends User {
    public HomeOwner(String name) {
        super(name, "Homeowner");
    }
}
