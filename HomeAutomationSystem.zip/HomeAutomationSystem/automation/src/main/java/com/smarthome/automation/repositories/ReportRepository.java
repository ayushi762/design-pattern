//package com.smarthome.automation.repositories;
//
//import com.smarthome.automation.models.Report;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//
//public class ReportRepository {
//    private final List<Report> reports = new ArrayList<>();
//    private int currentId = 1;
//
//    // Create a report based on type
//    public Report createReport(String reportType) {
//        String details;
//        switch (reportType.toLowerCase()) {
//            case "device_usage":
//                details = generateDeviceUsageReport();
//                break;
//            case "automation_rule_executions":
//                details = generateAutomationRuleExecutionsReport();
//                break;
//            case "user_activity":
//                details = generateUserActivityReport();
//                break;
//            default:
//                throw new IllegalArgumentException("Invalid report type: " + reportType);
//        }
//
//        Report report = new Report(currentId++, reportType, details, LocalDateTime.now());
//        reports.add(report);
//        return report;
//    }
//
//    public List<Report> getAllReports() {
//        return new ArrayList<>(reports);
//    }
//
//    private String generateDeviceUsageReport() {
//        return "Device Usage Report: Total active devices: 10, Total inactive devices: 2.";
//    }
//
//    private String generateAutomationRuleExecutionsReport() {
//        return "Automation Rule Executions Report: Total rules executed: 5, Failed executions: 1.";
//    }
//
//    private String generateUserActivityReport() {
//        return "User Activity Report: Total users: 3, Admin activities: 4, Homeowner activities: 12.";
//    }
//}
