//package com.smarthome.automation.repositories;
//
//import com.smarthome.automation.models.Notification;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class NotificationRepository {
//    private final List<Notification> notifications = new ArrayList<>();
//    private int currentId = 1;
//
//    public void addNotification(Notification notification) {
//        notification.setId(currentId++);
//        notifications.add(notification);
//    }
//
//    public List<Notification> getNotifications() {
//        return new ArrayList<>(notifications);
//    }
//}
