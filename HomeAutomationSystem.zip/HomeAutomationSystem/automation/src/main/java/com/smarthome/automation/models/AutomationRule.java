package com.smarthome.automation.models;

import java.time.LocalTime;

public class AutomationRule {
    private int id;
    private String name;
    private String condition; // e.g., "motionDetected == true"
    private String action;    // e.g., "setLightStatus(true)"
    private LocalTime scheduleTime; // Optional: null if condition-based

    public AutomationRule(int id, String name, String condition, String action, LocalTime scheduleTime) {
        this.id = id;
        this.name = name;
        this.condition = condition;
        this.action = action;
        this.scheduleTime = scheduleTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public LocalTime getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(LocalTime scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    @Override
    public String toString() {
        return "Rule [id=" + id + ", name=" + name + ", condition=" + condition + ", action=" + action +
                ", scheduleTime=" + scheduleTime + "]";
    }
}

