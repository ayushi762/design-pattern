package com.smarthome.automation.utils;

import com.smarthome.automation.services.RequestContext;

public interface Interceptor {
    void intercept(RequestContext context);
}
