package com.smarthome.automation.services;

import com.smarthome.automation.factories.UserFactory;
import com.smarthome.automation.models.User;
import com.smarthome.automation.repositories.UserRepository;
import com.smarthome.automation.utils.Logger;

import java.util.List;
//Factory method
public class UserManagementService {
	private static final String TAG = "UserManagement";
    private final UserRepository userRepository;

    public UserManagementService() {
        this.userRepository = new UserRepository();
    }

    public void addUser(String name, String role) {
        try {
        	User user = UserFactory.createUser(name, role);
//            User user = User.createUser(name, role);
            userRepository.addUser(user);
            Logger.info(TAG, "User added successfully: " + user);
        } catch (Exception e) {
            Logger.error(TAG, "Failed to add user: " + e.getMessage());
        }
    }

    public void updateUser(int id, String name, String role) {
        try {
        	User updatedUser = UserFactory.createUser(name, role);
//            User updatedUser = User.createUser(name, role);
            if (userRepository.updateUser(id, updatedUser)) {
                Logger.info(TAG, "User updated successfully: " + updatedUser);
            } else {
                Logger.warn(TAG, "User not found with ID: " + id);
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to update user: " + e.getMessage());
        }
    }

    public void deleteUser(int id) {
        try {
            if (userRepository.deleteUser(id)) {
                Logger.info(TAG, "User deleted successfully: ID " + id);
            } else {
                Logger.warn(TAG, "User not found with ID: " + id);
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to delete user: " + e.getMessage());
        }
    }

    public void viewUsers() {
        try {
            List<User> users = userRepository.getUsers();
            if (users.isEmpty()) {
                Logger.info(TAG, "No users registered.");
            } else {
              users.forEach(user -> Logger.info(TAG, user.toString()));
            }
        } catch (Exception e) {
            Logger.error(TAG, "Failed to fetch users: " + e.getMessage());
        }
    }
}
