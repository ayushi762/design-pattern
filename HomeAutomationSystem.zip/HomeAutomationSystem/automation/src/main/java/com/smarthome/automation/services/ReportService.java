package com.smarthome.automation.services;

import com.smarthome.automation.utils.Logger;

import java.time.LocalDateTime;
import java.util.List;

public class ReportService {

    public String generateReport(String tag) {
        StringBuilder report = new StringBuilder();
        report.append(tag).append(" Activity Report\n");
        report.append("Generated At: ").append(LocalDateTime.now()).append("\n\n");

        List<String> logs = Logger.getLogsByTag(tag);

        if (logs.isEmpty()) {
            report.append("No activity logged for ").append(tag).append(".\n");
        } else {
            for (String log : logs) {
                report.append(log).append("\n");
            }
        }

        return report.toString();
    }
}

//import com.smarthome.automation.models.Report;
//import com.smarthome.automation.repositories.ReportRepository;
//import com.smarthome.automation.utils.Logger;
//
////Resource Pool Pattern for managing reporting objects.
//public class ReportingService {
//    private final ReportRepository reportRepository;
//
//    public ReportingService() {
//        this.reportRepository = new ReportRepository();
//    }
//
//    public void generateReport(String reportType) {
//        try {
//            Report report = reportRepository.createReport(reportType);
//            Logger.info("Generated report: " + report.getDetails());
//        } catch (Exception e) {
//            Logger.error("Failed to generate report: " + e.getMessage());
//        }
//    }
//}
