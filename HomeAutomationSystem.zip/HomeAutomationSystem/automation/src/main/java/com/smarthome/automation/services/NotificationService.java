package com.smarthome.automation.services;

//import com.smarthome.automation.models.Notification;
//import com.smarthome.automation.repositories.NotificationRepository;
import com.smarthome.automation.models.Device;

import java.util.ArrayList;
import java.util.List;

public class NotificationService {
    // Singleton instance
    private static NotificationService instance;

    private final List<Observer> observers = new ArrayList<>();

    private NotificationService() {
    }

    public static synchronized NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    // Subscribe an observer (e.g., DeviceManager or User)
    public void subscribe(Observer observer) {
        observers.add(observer);
    }

    // Unsubscribe an observer
    public void unsubscribe(Observer observer) {
        observers.remove(observer);
    }

    // Notify all observers
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }

    // Notify users about device status change
    public void notifyDeviceStatusChange(Device device) {
        String message = "Device " + device.getName() + " is now " + (device.isStatus() ? "active" : "inactive");
        notifyObservers(message);
    }

    // Notify users about automation rule execution
    public void notifyRuleExecution(String ruleDescription) {
        String message = "Automation rule executed: " + ruleDescription;
        notifyObservers(message);
    }
}

// Observer Interface
interface Observer {
    void update(String message);
}

//
//// Publish-Subscribe Pattern for notifying users.
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//// Observer Interface
//interface Subscriber {
//    void update(String eventType, String message);
//}
//
//// Concrete Subscriber
//class ConsoleSubscriber implements Subscriber {
//    private String name;
//
//    public ConsoleSubscriber(String name) {
//        this.name = name;
//    }
//
//    @Override
//    public void update(String eventType, String message) {
//        System.out.println(name + " received [" + eventType + "] notification: " + message);
//    }
//}
//
//// Publisher
//public class NotificationService {
//    private final Map<String, List<Subscriber>> subscribers = new HashMap<>();
//
//    // Subscribe to events
//    public void subscribe(String eventType, Subscriber subscriber) {
//        this.subscribers.putIfAbsent(eventType, new ArrayList<>());
//        this.subscribers.get(eventType).add(subscriber);
//    }
//
//    // Unsubscribe from events
//    public void unsubscribe(String eventType, Subscriber subscriber) {
//        List<Subscriber> users = this.subscribers.get(eventType);
//        if (users != null) {
//            users.remove(subscriber);
//        }
//    }
//
//    // Notify subscribers
//    public void notify(String eventType, String message) {
//        List<Subscriber> users = this.subscribers.get(eventType);
//        if (users != null) {
//            users.forEach(subscriber -> subscriber.update(eventType, message));
//        }
//    }
//}
//

