package com.smarthome.automation.repositories;

import com.smarthome.automation.models.AutomationRule;

import java.util.ArrayList;
import java.util.List;

public class AutomationRulesRepository {
    private final List<AutomationRule> rules = new ArrayList<>();
    private int currentId = 1;

    public void addRule(AutomationRule rule) {
        rule.setId(currentId++);
        rules.add(rule);
    }

    public boolean updateRule(int id, AutomationRule updatedRule) {
        for (int i = 0; i < rules.size(); i++) {
            if (rules.get(i).getId() == id) {
                updatedRule.setId(id);
                rules.set(i, updatedRule);
                return true;
            }
        }
        return false;
    }

    public boolean deleteRule(int id) {
        return rules.removeIf(rule -> rule.getId() == id);
    }

    public List<AutomationRule> getRules() {
        return new ArrayList<>(rules);
    }
}

