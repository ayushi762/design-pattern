package com.smarthome.automation.utils;

import com.smarthome.automation.services.*;

public class ServiceLocator {

    private static DeviceManagementService deviceService;
    private static UserManagementService userService;
    private static AutomationRulesService automationRulesService;
    private static NotificationService notificationService;
    private static ReportService reportingService;

    // Private constructor to prevent instantiation
    private ServiceLocator() {}

    public static DeviceManagementService getDeviceService() {
        if (deviceService == null) {
        	NotificationService notificationService = getNotificationService();
            deviceService = new DeviceManagementService(notificationService); 
        }
        return deviceService;
    }

    public static UserManagementService getUserService() {
        if (userService == null) {
            userService = new UserManagementService();
        }
        return userService;
    }

    public static AutomationRulesService getAutomationRulesService() {
        if (automationRulesService == null) {
        	NotificationService notificationService = getNotificationService();
        	DeviceManagementService deviceService = getDeviceService();
            automationRulesService = new AutomationRulesService(deviceService, notificationService);
        }
        return automationRulesService;
    }
    
    public static NotificationService getNotificationService() {
        if (notificationService == null) {
            notificationService = NotificationService.getInstance();
        }
        return notificationService;
    }

    public static ReportService getReportingService() {
        if (reportingService == null) {
            reportingService = new ReportService();
        }
        return reportingService;
    }
}

