package com.smarthome.automation.services;

public class RequestContext {
    private String message;

    public RequestContext(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
